// netlify/functions/inventory.js
// Proxies MarketCheck API server-side so:
//   1. Your API key stays secret (set in Netlify env vars, not in code)
//   2. No CORS issues — the browser calls this function, not MarketCheck directly
//
// Set your key in Netlify dashboard:
//   Site settings → Environment variables → Add: MARKETCHECK_KEY = your_key

export const handler = async (event) => {
  const key = process.env.MARKETCHECK_KEY;

  if (!key) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "MARKETCHECK_KEY not set. Add it in Netlify → Environment variables." }),
    };
  }

  // Pass all query params from the frontend through to MarketCheck
  const params = new URLSearchParams(event.queryStringParameters || {});
  params.set("api_key", key);

  const url = `https://api.marketcheck.com/v2/search/car/active?${params}`;

  try {
    const res  = await fetch(url);
    const data = await res.json();

    if (!res.ok) {
      return {
        statusCode: res.status,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: data }),
      };
    }

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(data),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
